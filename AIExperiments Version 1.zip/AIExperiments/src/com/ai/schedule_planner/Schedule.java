package com.ai.schedule_planner;

public class Schedule 
{
	public String name;
	public float averageTimeNeeded;
	public float satisfaction;
	public float necessity; //Must always be between 0 and 0.9 (Expenses with 1 necessity, are always needed)
	public boolean isSingleTask; //If we need more than 1 of these, then make this false
	
	public Schedule(String name, float averageTimeNeeded, float satisfaction, float necessity, boolean isSingleTask)
	{
		this.name = name;
		this.averageTimeNeeded = averageTimeNeeded;
		this.satisfaction = satisfaction;
		this.necessity = necessity;
		this.isSingleTask = isSingleTask;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return name + "," + averageTimeNeeded + "(S:" +  satisfaction + ",N:" + necessity + ")";
	}
	
	public boolean equals_bkp(Object obj) {
		
		try {
			Schedule exp = (Schedule)obj;
			if(exp.name.equals(name))
				return true;
			else
				return false;
		} catch (Exception e) {
			return false;
		}
		
	}
}
