package com.ai.schedule_planner;
import java.util.ArrayList;


public class SolutionForSchedule 
{
	public ArrayList<Schedule> lstObjects;
	
	public SolutionForSchedule()
	{
		lstObjects = new ArrayList<Schedule>();
	}
	
	public float totalCost() 
	{
		float cost = 0;
		for (Schedule expense : lstObjects) {
			cost = cost + expense.averageTimeNeeded;
		}
		return cost;
	}
	
	public float totalSatisfaction() 
	{
		float result = 0;
		for (Schedule expense : lstObjects) {
			result = result + expense.satisfaction;
		}
		return result;
	}
	
	public float averageSatisfaction() 
	{
		float result = 0;
		for (Schedule expense : lstObjects) {
			result = result + expense.satisfaction;
		}
		return result/lstObjects.size();
	}
	
	public float totalNecessity() 
	{
		float result = 0;
		for (Schedule expense : lstObjects) {
			result = result + expense.necessity;
		}
		return result;
	}
	
	public float averageNecessity() 
	{
		float result = 0;
		for (Schedule expense : lstObjects) {
			result = result + expense.necessity;
		}
		return result/lstObjects.size();
	}
	
	public boolean checkIfSingleAndAlreadyExists(Schedule exp)
	{
		//If it is not single, then return false
		if(exp.isSingleTask == false)
			return false;
		
		//Check in the list, if contains, then return true
		if(lstObjects.contains(exp))
			return true;
		
		//This is a single, but not yet evaluated
		return false;
	}
	
	public void addObject(Schedule obj)
	{
		lstObjects.add(obj);
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String out_str = "";
		
		ArrayList<Schedule> lstUniqueExpense = new ArrayList<Schedule>();
		for (Schedule exp : lstObjects) 
		{
			boolean found = false;
			int found_index = 0;
			
			for(int count=0;count<lstUniqueExpense.size();count++)
			{
				if(lstUniqueExpense.get(count).name.equals(exp.name))
				{
					found = true;
					found_index = count;
					break;
				}
			}
			
			if(found)
			{
				Schedule exp_copy = lstUniqueExpense.get(found_index);
				exp_copy.averageTimeNeeded = exp_copy.averageTimeNeeded + exp.averageTimeNeeded;
				lstUniqueExpense.set(found_index, exp_copy);
			}
			else
			{
				Schedule exp_copy = new Schedule(exp.name, exp.averageTimeNeeded, exp.satisfaction, exp.necessity, exp.isSingleTask);
				lstUniqueExpense.add(exp_copy);
			}
		}
		
		SolutionForSchedule finalSol = new SolutionForSchedule();
		//Solution finalSol = this;
		for (Schedule expense : lstUniqueExpense) {
			finalSol.addObject(expense);
			out_str = out_str + expense + "\n";
		}
		
		out_str = out_str + "\n\nTotal Cost:" + finalSol.totalCost() + ", Satisfaction:" + finalSol.averageSatisfaction() + ", Necessity:" + finalSol.averageNecessity();
		
		return out_str;
	}
	
	public float findUniqueObjects()
	{
		float uniqueExpenses = 0;
		
		ArrayList<Schedule> lstUniqueExpense = new ArrayList<Schedule>();
		for (Schedule exp : lstObjects) 
		{
			if(lstUniqueExpense.contains(exp))
			{
				
			}
			else
			{
				lstUniqueExpense.add(exp);
				uniqueExpenses = uniqueExpenses + 1;
			}
				
		}
		
		return uniqueExpenses;
	}
	
	public float evaluateFitness(float totalAmount)
	{
		float uniqueExpenses = findUniqueObjects();
		float fitness = (totalCost() / totalAmount) + averageSatisfaction() + averageNecessity() + uniqueExpenses;
		return fitness;
	}
}
