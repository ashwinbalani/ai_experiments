package com.ai.schedule_planner;
import java.util.ArrayList;

import com.ai.expense_planner.TrueRandom;


public class ScheduleOptimizer 
{
	public static SolutionForSchedule optimizeSchedule(float totalTime,float totalSolutions,float totalGenerations,float crossOverFactor,ArrayList<Schedule> lstSchedule)
	{
		//Initialize a list of solutions
		ArrayList<SolutionForSchedule> lstSolutions = new ArrayList<SolutionForSchedule>();
		TrueRandom rnd = new TrueRandom(lstSchedule.size());
		
		for(int gen=0;gen<totalGenerations;gen++)
		{
			if(gen == 0)
			{
				for(int count=0;count<totalSolutions;count++)
				{
					//Generate random solutions
					SolutionForSchedule sol = new SolutionForSchedule();
					while(sol.totalCost() < totalTime)
					{
						int index = rnd.generateRandom();
						Schedule exp = lstSchedule.get(index);
						
						if(sol.checkIfSingleAndAlreadyExists(exp) == true)
						{
							//This is a single expense, and already exists
							continue;
						}
						else
						{
							//Add this
							if((exp.averageTimeNeeded+sol.totalCost()) > totalTime)
								break;
							
							//System.out.println(index);
							sol.addObject(exp);
						}
					}
					//Add to list of solutions
					lstSolutions.add(sol);
				}
			}
			else
			{
				//Evaluate fitness of each solution
				//Fitness = (total_cost/total_amount) + average satisfaction + average necessity + (unique expenses / total expenses)
				
				ArrayList<Float> lstFitness = new ArrayList<Float>();
				float mean_fitness = 0;
				for(int count=0;count<lstSolutions.size();count++)
				{
					SolutionForSchedule sol = lstSolutions.get(count);
					float fitness = sol.evaluateFitness(totalTime);
					
					lstFitness.add(fitness);
					
					//Evaluate mean as well
					mean_fitness = mean_fitness + fitness;
				}
				
				mean_fitness = mean_fitness/lstSolutions.size();
				
				ArrayList<SolutionForSchedule> lstNewSolutions = new ArrayList<SolutionForSchedule>();
				for(int count=0;count<lstSolutions.size();count++)
				{
					//Cross over the fit solutions
					if(lstFitness.get(count) > (mean_fitness * crossOverFactor))
					{
						lstNewSolutions.add(lstSolutions.get(count));
					}
					else
					{
						//We need to mutate the solution
						SolutionForSchedule sol = new SolutionForSchedule();
						while(sol.totalCost() < totalTime)
						{
							int index = rnd.generateRandom();
							Schedule exp = lstSchedule.get(index);
							
							if(sol.checkIfSingleAndAlreadyExists(exp) == true)
							{
								//This is a single expense, and already exists
								continue;
							}
							else
							{
								//Add this
								if((exp.averageTimeNeeded+sol.totalCost()) > totalTime)
									break;
								
								//System.out.println(index);
								sol.addObject(exp);
							}
						}
						
						lstNewSolutions.add(sol);
					}
				}
				
				lstSolutions = null;
				lstSolutions = lstNewSolutions;
			}
		}
		
		float best_fitness = 0;
		int best_fit_index = 0;
		for(int count=0;count<lstSolutions.size();count++)
		{
			SolutionForSchedule sol = lstSolutions.get(count);
			float fitness = sol.evaluateFitness(totalTime);
			
			if(fitness > best_fitness)
			{
				best_fitness = fitness;
				best_fit_index = count;
			}
		}
		
		SolutionForSchedule sol = lstSolutions.get(best_fit_index);
		return sol;
	}
}
