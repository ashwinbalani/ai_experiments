package com.ai.expense_planner;

public class Expense 
{
	public String name;
	public float averageCost;
	public float satisfaction;
	public float necessity; //Must always be between 0 and 0.9 (Expenses with 1 necessity, are always needed)
	public boolean isSingleExpense; //If we need more than 1 of these, then make this false
	
	public Expense(String name, float averageCost, float satisfaction, float necessity, boolean isSingleExpense)
	{
		this.name = name;
		this.averageCost = averageCost;
		this.satisfaction = satisfaction;
		this.necessity = necessity;
		this.isSingleExpense = isSingleExpense;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return name + "," + averageCost + "(S:" +  satisfaction + ",N:" + necessity + ")";
	}
	
	public boolean equals_bkp(Object obj) {
		
		try {
			Expense exp = (Expense)obj;
			if(exp.name.equals(name))
				return true;
			else
				return false;
		} catch (Exception e) {
			return false;
		}
		
	}
}
