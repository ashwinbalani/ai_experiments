package com.ai.expense_planner;
import java.util.ArrayList;
import java.util.Random;


public class TrueRandom 
{
	int max_rand_value = 100;
	Random rnd;
	ArrayList<Integer> lstRandomIndices;
	
	public TrueRandom(int MaxValue)
	{
		max_rand_value = MaxValue;
		rnd = new Random();
		lstRandomIndices = new ArrayList<Integer>();
	}
	
	public int generateRandom()
	{
		int rnd_val = rnd.nextInt(max_rand_value);
		if(lstRandomIndices.size() == max_rand_value)
		{
			lstRandomIndices = new ArrayList<Integer>();
			lstRandomIndices.add(rnd_val);
			return rnd_val;
		}
		
		while(lstRandomIndices.contains(rnd_val))
		{
			rnd_val = rnd.nextInt(max_rand_value);
		}
		lstRandomIndices.add(rnd_val);
		return rnd_val;
	}
}
