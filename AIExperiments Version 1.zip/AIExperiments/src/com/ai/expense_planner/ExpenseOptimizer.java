package com.ai.expense_planner;
import java.util.ArrayList;


public class ExpenseOptimizer 
{
	public static void main(String[] args) 
	{
		float totalAmount = 50000; 
		int totalSolutions = 50;
		int totalGenerations = 1000;
		float crossOverFactor = 1.2f; //Pass these many solutions to next iteration
		
		ArrayList<Expense> lstExpense = new ArrayList<Expense>();
		lstExpense.add(new Expense("Holiday", 5000, 0.2f, 0.6f, false));
		lstExpense.add(new Expense("Dance Class", 2000, 0.4f, 0.3f, true));
		lstExpense.add(new Expense("Fishing", 3500, 0.45f, 0.1f, true));
		lstExpense.add(new Expense("Movies", 200, 0.6f, 0.2f, false));
		lstExpense.add(new Expense("Eating out", 500, 0.7f, 0.4f, false));
		lstExpense.add(new Expense("Ice Creams", 1000, 0.6f, 0.5f, false));
		lstExpense.add(new Expense("Karate Classes", 3000, 0.7f, 0.3f, true));
		
		//Initialize a list of solutions
		ArrayList<SolutionForExpense> lstSolutions = new ArrayList<SolutionForExpense>();
		TrueRandom rnd = new TrueRandom(lstExpense.size());
		
		for(int gen=0;gen<totalGenerations;gen++)
		{
			if(gen == 0)
			{
				for(int count=0;count<totalSolutions;count++)
				{
					//Generate random solutions
					SolutionForExpense sol = new SolutionForExpense();
					while(sol.totalCost() < totalAmount)
					{
						int index = rnd.generateRandom();
						Expense exp = lstExpense.get(index);
						
						if(sol.checkIfSingleExpenseAndAlreadyExists(exp) == true)
						{
							//This is a single expense, and already exists
							continue;
						}
						else
						{
							//Add this
							if((exp.averageCost+sol.totalCost()) > totalAmount)
								break;
							
							//System.out.println(index);
							sol.addExpense(exp);
						}
					}
					System.out.println("");
					System.out.println(sol + ", Fitness:" + sol.evaluateFitness(totalAmount));
					
					//Add to list of solutions
					lstSolutions.add(sol);
				}
			}
			else
			{
				//Evaluate fitness of each solution
				//Fitness = (total_cost/total_amount) + average satisfaction + average necessity + (unique expenses / total expenses)
				
				System.out.println("Iteration " + gen);
				ArrayList<Float> lstFitness = new ArrayList<Float>();
				float mean_fitness = 0;
				for(int count=0;count<lstSolutions.size();count++)
				{
					SolutionForExpense sol = lstSolutions.get(count);
					float fitness = sol.evaluateFitness(totalAmount);
					
					lstFitness.add(fitness);
					
					//Evaluate mean as well
					mean_fitness = mean_fitness + fitness;
				}
				
				mean_fitness = mean_fitness/lstSolutions.size();
				
				ArrayList<SolutionForExpense> lstNewSolutions = new ArrayList<SolutionForExpense>();
				for(int count=0;count<lstSolutions.size();count++)
				{
					//Cross over the fit solutions
					if(lstFitness.get(count) > (mean_fitness * crossOverFactor))
					{
						lstNewSolutions.add(lstSolutions.get(count));
					}
					else
					{
						//We need to mutate the solution
						SolutionForExpense sol = new SolutionForExpense();
						while(sol.totalCost() < totalAmount)
						{
							int index = rnd.generateRandom();
							Expense exp = lstExpense.get(index);
							
							if(sol.checkIfSingleExpenseAndAlreadyExists(exp) == true)
							{
								//This is a single expense, and already exists
								continue;
							}
							else
							{
								//Add this
								if((exp.averageCost+sol.totalCost()) > totalAmount)
									break;
								
								//System.out.println(index);
								sol.addExpense(exp);
							}
						}
						
						System.out.println("");
						System.out.println(sol + ", Fitness:" + sol.evaluateFitness(totalAmount));
						lstNewSolutions.add(sol);
					}
				}
				
				lstSolutions = null;
				lstSolutions = lstNewSolutions;
			}
		}
		
		float best_fitness = 0;
		int best_fit_index = 0;
		for(int count=0;count<lstSolutions.size();count++)
		{
			SolutionForExpense sol = lstSolutions.get(count);
			float fitness = sol.evaluateFitness(totalAmount);
			
			if(fitness > best_fitness)
			{
				best_fitness = fitness;
				best_fit_index = count;
			}
		}
		
		SolutionForExpense sol = lstSolutions.get(best_fit_index);
		System.out.println("\n\nBest solution\n\n" + sol + ", Fitness:" + sol.evaluateFitness(totalAmount));
	}
	
	public static SolutionForExpense optimizeExpense(float totalAmount,float totalSolutions,float totalGenerations,float crossOverFactor,ArrayList<Expense> lstExpense)
	{
		//Initialize a list of solutions
		ArrayList<SolutionForExpense> lstSolutions = new ArrayList<SolutionForExpense>();
		TrueRandom rnd = new TrueRandom(lstExpense.size());
		
		for(int gen=0;gen<totalGenerations;gen++)
		{
			if(gen == 0)
			{
				for(int count=0;count<totalSolutions;count++)
				{
					//Generate random solutions
					SolutionForExpense sol = new SolutionForExpense();
					while(sol.totalCost() < totalAmount)
					{
						int index = rnd.generateRandom();
						Expense exp = lstExpense.get(index);
						
						if(sol.checkIfSingleExpenseAndAlreadyExists(exp) == true)
						{
							//This is a single expense, and already exists
							continue;
						}
						else
						{
							//Add this
							if((exp.averageCost+sol.totalCost()) > totalAmount)
								break;
							
							//System.out.println(index);
							sol.addExpense(exp);
						}
					}
					//Add to list of solutions
					lstSolutions.add(sol);
				}
			}
			else
			{
				//Evaluate fitness of each solution
				//Fitness = (total_cost/total_amount) + average satisfaction + average necessity + (unique expenses / total expenses)
				
				ArrayList<Float> lstFitness = new ArrayList<Float>();
				float mean_fitness = 0;
				for(int count=0;count<lstSolutions.size();count++)
				{
					SolutionForExpense sol = lstSolutions.get(count);
					float fitness = sol.evaluateFitness(totalAmount);
					
					lstFitness.add(fitness);
					
					//Evaluate mean as well
					mean_fitness = mean_fitness + fitness;
				}
				
				mean_fitness = mean_fitness/lstSolutions.size();
				
				ArrayList<SolutionForExpense> lstNewSolutions = new ArrayList<SolutionForExpense>();
				for(int count=0;count<lstSolutions.size();count++)
				{
					//Cross over the fit solutions
					if(lstFitness.get(count) > (mean_fitness * crossOverFactor))
					{
						lstNewSolutions.add(lstSolutions.get(count));
					}
					else
					{
						//We need to mutate the solution
						SolutionForExpense sol = new SolutionForExpense();
						while(sol.totalCost() < totalAmount)
						{
							int index = rnd.generateRandom();
							Expense exp = lstExpense.get(index);
							
							if(sol.checkIfSingleExpenseAndAlreadyExists(exp) == true)
							{
								//This is a single expense, and already exists
								continue;
							}
							else
							{
								//Add this
								if((exp.averageCost+sol.totalCost()) > totalAmount)
									break;
								
								//System.out.println(index);
								sol.addExpense(exp);
							}
						}
						
						lstNewSolutions.add(sol);
					}
				}
				
				lstSolutions = null;
				lstSolutions = lstNewSolutions;
			}
		}
		
		float best_fitness = 0;
		int best_fit_index = 0;
		for(int count=0;count<lstSolutions.size();count++)
		{
			SolutionForExpense sol = lstSolutions.get(count);
			float fitness = sol.evaluateFitness(totalAmount);
			
			if(fitness > best_fitness)
			{
				best_fitness = fitness;
				best_fit_index = count;
			}
		}
		
		SolutionForExpense sol = lstSolutions.get(best_fit_index);
		return sol;
	}
}
