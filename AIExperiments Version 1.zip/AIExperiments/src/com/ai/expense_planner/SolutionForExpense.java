package com.ai.expense_planner;
import java.util.ArrayList;


public class SolutionForExpense 
{
	public ArrayList<Expense> lstExpenses;
	
	public SolutionForExpense()
	{
		lstExpenses = new ArrayList<Expense>();
	}
	
	public float totalCost() 
	{
		float cost = 0;
		for (Expense expense : lstExpenses) {
			cost = cost + expense.averageCost;
		}
		return cost;
	}
	
	public float totalSatisfaction() 
	{
		float result = 0;
		for (Expense expense : lstExpenses) {
			result = result + expense.satisfaction;
		}
		return result;
	}
	
	public float averageSatisfaction() 
	{
		float result = 0;
		for (Expense expense : lstExpenses) {
			result = result + expense.satisfaction;
		}
		return result/lstExpenses.size();
	}
	
	public float totalNecessity() 
	{
		float result = 0;
		for (Expense expense : lstExpenses) {
			result = result + expense.necessity;
		}
		return result;
	}
	
	public float averageNecessity() 
	{
		float result = 0;
		for (Expense expense : lstExpenses) {
			result = result + expense.necessity;
		}
		return result/lstExpenses.size();
	}
	
	public boolean checkIfSingleExpenseAndAlreadyExists(Expense exp)
	{
		//If it is not single expense, then return false
		if(exp.isSingleExpense == false)
			return false;
		
		//Check in the list, if contains, then return true
		if(lstExpenses.contains(exp))
			return true;
		
		//This is a single expense, but not yet evaluated
		return false;
	}
	
	public void addExpense(Expense exp)
	{
		lstExpenses.add(exp);
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String out_str = "";
		
		ArrayList<Expense> lstUniqueExpense = new ArrayList<Expense>();
		for (Expense exp : lstExpenses) 
		{
			boolean found = false;
			int found_index = 0;
			
			for(int count=0;count<lstUniqueExpense.size();count++)
			{
				if(lstUniqueExpense.get(count).name.equals(exp.name))
				{
					found = true;
					found_index = count;
					break;
				}
			}
			
			if(found)
			{
				Expense exp_copy = lstUniqueExpense.get(found_index);
				exp_copy.averageCost = exp_copy.averageCost + exp.averageCost;
				lstUniqueExpense.set(found_index, exp_copy);
			}
			else
			{
				Expense exp_copy = new Expense(exp.name, exp.averageCost, exp.satisfaction, exp.necessity, exp.isSingleExpense);
				lstUniqueExpense.add(exp_copy);
			}
		}
		
		SolutionForExpense finalSol = new SolutionForExpense();
		//Solution finalSol = this;
		for (Expense expense : lstUniqueExpense) {
			finalSol.addExpense(expense);
			out_str = out_str + expense + "\n";
		}
		
		out_str = out_str + "\n\nTotal Cost:" + finalSol.totalCost() + ", Satisfaction:" + finalSol.averageSatisfaction() + ", Necessity:" + finalSol.averageNecessity();
		
		return out_str;
	}
	
	public float findUniqueExpenses()
	{
		float uniqueExpenses = 0;
		
		ArrayList<Expense> lstUniqueExpense = new ArrayList<Expense>();
		for (Expense exp : lstExpenses) 
		{
			if(lstUniqueExpense.contains(exp))
			{
				
			}
			else
			{
				lstUniqueExpense.add(exp);
				uniqueExpenses = uniqueExpenses + 1;
			}
				
		}
		
		return uniqueExpenses;
	}
	
	public float evaluateFitness(float totalAmount)
	{
		float uniqueExpenses = findUniqueExpenses();
		float fitness = (totalCost() / totalAmount) + averageSatisfaction() + averageNecessity() + uniqueExpenses;
		return fitness;
	}
}
