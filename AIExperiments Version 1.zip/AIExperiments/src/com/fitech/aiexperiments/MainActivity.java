package com.fitech.aiexperiments;

import java.util.ArrayList;

import com.ai.expense_planner.Expense;
import com.ai.expense_planner.ExpenseOptimizer;
import com.ai.expense_planner.SolutionForExpense;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity 
{
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		final ArrayList<Expense> lstExpenses = new ArrayList<Expense>();
		lstExpenses.add(new Expense("Holiday", 5000, 0.2f, 0.6f, false));
		lstExpenses.add(new Expense("Dance Class", 2000, 0.4f, 0.3f, true));
		lstExpenses.add(new Expense("Fishing", 3500, 0.45f, 0.1f, true));
		lstExpenses.add(new Expense("Movies", 200, 0.6f, 0.2f, false));
		lstExpenses.add(new Expense("Eating out", 500, 0.7f, 0.4f, false));
		lstExpenses.add(new Expense("Ice Creams", 1000, 0.6f, 0.5f, false));
		lstExpenses.add(new Expense("Karate Classes", 3000, 0.7f, 0.3f, true));
		
		final EditText txtTotalBudget = (EditText)findViewById(R.id.txtTotalBudget);
		final ListView lstListExpenses = (ListView)findViewById(R.id.lstExpenseItems);
		final Button btnAddItem = (Button)findViewById(R.id.btnAddExpenseItem);
		final Button btnPlanAI = (Button)findViewById(R.id.btnPlanExpensesAI);
		
		final TextView lblHeader = (TextView)findViewById(R.id.lblAIHeader);
		final TextView lblTotal = (TextView)findViewById(R.id.lblTotalAvailable);
		lblHeader.setText("Manage your Expenses via AI");
		lblTotal.setText("Total amount to spend");
		btnAddItem.setText("Add expense item");
		
		lstListExpenses.setAdapter(new ArrayAdapter<Expense>(MainActivity.this, android.R.layout.simple_list_item_1,lstExpenses));
		
		btnPlanAI.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) 
			{
				try {
					aiRun(Float.parseFloat(txtTotalBudget.getText().toString()), lstExpenses);
				} catch (Exception e) {
					Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
				}
			}
		});
		
		lstListExpenses.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				if(position >= 0)
				{
					lstExpenses.remove(position);
					lstListExpenses.setAdapter(new ArrayAdapter<Expense>(MainActivity.this, android.R.layout.simple_list_item_1,lstExpenses));
				}
			}
		});
		
		btnAddItem.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				final Dialog dlg = new Dialog(MainActivity.this);
				dlg.setContentView(R.layout.add_object);
				final EditText txtName = (EditText)dlg.findViewById(R.id.txtExpenseName);
				final EditText txtCost = (EditText)dlg.findViewById(R.id.txtExpenseCost);
				final SeekBar skbSatisfaction = (SeekBar)dlg.findViewById(R.id.skbSatisfaction);
				final SeekBar skbNecessity = (SeekBar)dlg.findViewById(R.id.skbNecessity);
				skbNecessity.setMax(100);
				skbSatisfaction.setMax(100);
				final CheckBox chkIsMultiple = (CheckBox)dlg.findViewById(R.id.chkIsExpenseMultiple);
				final Button btnAdd = (Button)dlg.findViewById(R.id.btnAddExpense);
				
				txtName.setHint("Expense Name");
				txtCost.setHint("Cost for this expense");
				
				btnAdd.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						float satisfaction = (float)skbSatisfaction.getProgress() / skbSatisfaction.getMax();
						if(satisfaction <= 0 || satisfaction >= 1)
							satisfaction = 0.9f;
						
						float necessity = (float)skbNecessity.getProgress() / skbNecessity.getMax();
						if(necessity <= 0 || necessity >= 1)
							necessity = 0.9f;
						
						boolean isSingleExpense = !chkIsMultiple.isChecked();
						
						Expense exp = new Expense(txtName.getText().toString(), Float.parseFloat(txtCost.getText().toString()), satisfaction, necessity, isSingleExpense);
						
						lstExpenses.add(exp);
						
						lstListExpenses.setAdapter(new ArrayAdapter<Expense>(MainActivity.this, android.R.layout.simple_list_item_1,lstExpenses));
						dlg.cancel();
					}
				});
				dlg.show();
			}
		});
	}

	public void aiRun(float budget,ArrayList<Expense> lstExpenses)
	{
		final float budget_ = budget;
		final ArrayList<Expense> lstExpenses_ = lstExpenses;
		
		AsyncTask<String, String, Void> atask = new AsyncTask<String, String, Void>() {
			
			ProgressDialog pd;
			
			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();
				
				pd = ProgressDialog.show(MainActivity.this, "Working on it", "Process via AI");
			}
			@Override
			protected Void doInBackground(String... params) {
				try {
					float total_budget = budget_;
					SolutionForExpense finalSolution = ExpenseOptimizer.optimizeExpense(total_budget, 10, 500, 1.2f, lstExpenses_);
					
					publishProgress(finalSolution.toString());
				} catch (Exception e) {
					// TODO: handle exception
					publishProgress(e.getMessage());
				}
				
				return null;
			}
			
			@Override
			protected void onProgressUpdate(String... values) {
				// TODO Auto-generated method stub
				super.onProgressUpdate(values);
				pd.dismiss();
				
				String val = values[0];
				
				AlertDialog.Builder abuild = new AlertDialog.Builder(MainActivity.this);
				abuild.setTitle("Optimized Expenses");
				abuild.setMessage(val);
				abuild.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						dialog.cancel();
					}
				});
				abuild.setNegativeButton("Re-Run AI", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						dialog.cancel();
						aiRun(budget_,lstExpenses_);
					}
				});
				
				abuild.create().show();
			}
		};
		atask.execute("");
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// TODO Auto-generated method stub
		MenuInflater inflate = getMenuInflater();
		inflate.inflate(R.menu.main, menu);
		return super.onCreateOptionsMenu(menu);
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		Intent intLaunch = null;
		if(item.getItemId() == R.id.mnuExpenseOptimizer)
		{
			intLaunch = new Intent(MainActivity.this, MainActivity.class);
		}
		else if(item.getItemId() == R.id.mnuScheduleOptimizer)
		{
			intLaunch = new Intent(MainActivity.this, ScheduleOptimizerActivity.class);
		}
		
		if(intLaunch != null)
		{
			startActivity(intLaunch);
			return true;
		}	
		return super.onOptionsItemSelected(item);
	}
	
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		
		finish();
	}
}
