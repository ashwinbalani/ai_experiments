package com.fitech.aiexperiments;

import java.util.ArrayList;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

import com.ai.schedule_planner.Schedule;
import com.ai.schedule_planner.ScheduleOptimizer;
import com.ai.schedule_planner.SolutionForSchedule;

public class ScheduleOptimizerActivity extends MainActivity 
{
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		final ArrayList<Schedule> lstActivities = new ArrayList<Schedule>();
		lstActivities.add(new Schedule("Holiday", 10, 0.2f, 0.6f, false));
		lstActivities.add(new Schedule("Dance Class", 5, 0.4f, 0.3f, true));
		lstActivities.add(new Schedule("Fishing", 1, 0.45f, 0.1f, true));
		lstActivities.add(new Schedule("Movies", 1, 0.6f, 0.2f, false));
		lstActivities.add(new Schedule("Eating out", 1, 0.7f, 0.4f, false));
		lstActivities.add(new Schedule("Ice Creams", 1, 0.6f, 0.5f, false));
		lstActivities.add(new Schedule("Karate Classes", 5, 0.7f, 0.3f, true));
		
		final EditText txtTotalBudget = (EditText)findViewById(R.id.txtTotalBudget);
		final ListView lstListExpenses = (ListView)findViewById(R.id.lstExpenseItems);
		final Button btnAddItem = (Button)findViewById(R.id.btnAddExpenseItem);
		final Button btnPlanAI = (Button)findViewById(R.id.btnPlanExpensesAI);
		lstListExpenses.setAdapter(new ArrayAdapter<Schedule>(ScheduleOptimizerActivity.this, android.R.layout.simple_list_item_1,lstActivities));
		txtTotalBudget.setText("25");
		
		final TextView lblHeader = (TextView)findViewById(R.id.lblAIHeader);
		final TextView lblTotal = (TextView)findViewById(R.id.lblTotalAvailable);
		lblHeader.setText("Manage your Schedule via AI");
		lblTotal.setText("Total Time you want to Invest");
		btnAddItem.setText("Add activity item");
		
		btnPlanAI.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) 
			{
				try {
					aiRun2(Float.parseFloat(txtTotalBudget.getText().toString()), lstActivities);
				} catch (Exception e) {
					Toast.makeText(ScheduleOptimizerActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
				}
			}
		});
		
		lstListExpenses.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				if(position >= 0)
				{
					lstActivities.remove(position);
					lstListExpenses.setAdapter(new ArrayAdapter<Schedule>(ScheduleOptimizerActivity.this, android.R.layout.simple_list_item_1,lstActivities));
				}
			}
		});
		
		btnAddItem.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				final Dialog dlg = new Dialog(ScheduleOptimizerActivity.this);
				dlg.setContentView(R.layout.add_object);
				final EditText txtName = (EditText)dlg.findViewById(R.id.txtExpenseName);
				final EditText txtCost = (EditText)dlg.findViewById(R.id.txtExpenseCost);
				final SeekBar skbSatisfaction = (SeekBar)dlg.findViewById(R.id.skbSatisfaction);
				final SeekBar skbNecessity = (SeekBar)dlg.findViewById(R.id.skbNecessity);
				skbNecessity.setMax(100);
				skbSatisfaction.setMax(100);
				final CheckBox chkIsMultiple = (CheckBox)dlg.findViewById(R.id.chkIsExpenseMultiple);
				final Button btnAdd = (Button)dlg.findViewById(R.id.btnAddExpense);
				
				txtName.setHint("Task Name");
				txtCost.setHint("Time needed for this task");
				
				btnAdd.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						float satisfaction = (float)skbSatisfaction.getProgress() / skbSatisfaction.getMax();
						if(satisfaction <= 0 || satisfaction >= 1)
							satisfaction = 0.9f;
						
						float necessity = (float)skbNecessity.getProgress() / skbNecessity.getMax();
						if(necessity <= 0 || necessity >= 1)
							necessity = 0.9f;
						
						boolean isSingleExpense = !chkIsMultiple.isChecked();
						
						Schedule exp = new Schedule(txtName.getText().toString(), Float.parseFloat(txtCost.getText().toString()), satisfaction, necessity, isSingleExpense);
						
						lstActivities.add(exp);
						
						lstListExpenses.setAdapter(new ArrayAdapter<Schedule>(ScheduleOptimizerActivity.this, android.R.layout.simple_list_item_1,lstActivities));
						dlg.cancel();
					}
				});
				dlg.show();
			}
		});
	}

	public void aiRun2(float totalTime,ArrayList<Schedule> lstActivities)
	{
		final float totalTime_ = totalTime;
		final ArrayList<Schedule> lstActivities_ = lstActivities;
		
		AsyncTask<String, String, Void> atask = new AsyncTask<String, String, Void>() {
			
			ProgressDialog pd;
			
			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();
				
				pd = ProgressDialog.show(ScheduleOptimizerActivity.this, "Working on it", "Process via AI");
			}
			@Override
			protected Void doInBackground(String... params) {
				try {
					SolutionForSchedule finalSolution = ScheduleOptimizer.optimizeSchedule(totalTime_, 10, 500, 1.2f, lstActivities_);
					
					publishProgress(finalSolution.toString());
				} catch (Exception e) {
					// TODO: handle exception
					publishProgress(e.getMessage());
				}
				
				return null;
			}
			
			@Override
			protected void onProgressUpdate(String... values) {
				// TODO Auto-generated method stub
				super.onProgressUpdate(values);
				pd.dismiss();
				
				String val = values[0];
				
				AlertDialog.Builder abuild = new AlertDialog.Builder(ScheduleOptimizerActivity.this);
				abuild.setTitle("Optimized Schedule");
				abuild.setMessage(val);
				abuild.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						dialog.cancel();
					}
				});
				abuild.setNegativeButton("Re-Run AI", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						dialog.cancel();
						aiRun2(totalTime_,lstActivities_);
					}
				});
				
				abuild.create().show();
			}
		};
		atask.execute("");
	}
}
